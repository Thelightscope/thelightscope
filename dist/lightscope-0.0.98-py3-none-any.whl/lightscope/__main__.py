# lightscope/__main__.py
from .lightscope_core import lightscope_run

if __name__ == "__main__":
    lightscope_run()
