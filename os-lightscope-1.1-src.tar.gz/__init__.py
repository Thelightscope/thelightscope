# LightScope for OPNsense
