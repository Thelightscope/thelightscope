# -*- coding: utf-8 -*-
# @Author: JanKinCai
# @Date:   2019-11-12 09:18:35
# @Last Modified by:   JanKinCai
# @Last Modified time: 2019-11-12 09:22:08
from pylibpcap.base import get_iface_list



print(get_iface_list())
